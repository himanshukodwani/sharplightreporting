﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SharpLightReporting_SalesReporting
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button_GenerateSalesReport_Click(object sender, EventArgs e)
        {
            SharpLightReporting.ReportEngine reportEngine = new SharpLightReporting.ReportEngine();
            reportEngine.NotifyReportLogEvent += ReportEngine_NotifyReportLogEvent;
            reportEngine.ProcessReport("SalesReportTemplate.xlsx", "SalesReport.xlsx", new SalesReportModel());
            Process.Start("SalesReport.xlsx");
        }

        private void ReportEngine_NotifyReportLogEvent(string log)
        {
            MessageBox.Show(log);
        }
    }
}